MODULE MOD_MAIN
GLOBAL PROC main()
While(1)

MoveAbsJ(j1,v1000,z50,tool0,wobj0); //3s 1s
MoveAbsJ(j2,v1000,z50,tool0,wobj0);
MoveAbsJ(j3,v1000,z50,tool0,wobj0); 
MoveAbsJ(j4,v1000,z50,tool0,wobj0);
Wait(5);
MoveAbsJ(j1,v1000,z50,tool0,wobj0); 
MoveAbsJ(j2,v1000,z50,tool0,wobj0);
MoveAbsJ(j3,v1000,z50,tool0,wobj0); 
MoveAbsJ(j4,v1000,z50,tool0,wobj0);
Wait(10.2);
endwhile


ENDPROC

ENDMODULE