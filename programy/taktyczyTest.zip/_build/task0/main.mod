MODULE MOD_MAIN
GLOBAL PROC main()
While(1)


MoveAbsJ(j3, v1000,z50,tool0,wobj0);
MoveAbsJ(j4, v1000,z50,tool0,wobj0);
MoveAbsJ(j3, v1000,z50,tool0,wobj0);
MoveAbsJ(j4, v1000,z50,tool0,wobj0);
MoveAbsJ(j3, v1000,z50,tool0,wobj0);
MoveAbsJ(j4, v1000,z50,tool0,wobj0);

MoveAbsJ(j7, v1000,z50,tool0,wobj0);

Endwhile
ENDPROC
ENDMODULE