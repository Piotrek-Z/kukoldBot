#include "videoreceiver.h"
#include <QDebug>

VideoReceiver::VideoReceiver(QObject *parent) : QObject(parent) {
    // Przenosimy ten obiekt do osobnego wątku roboczego
    moveToThread(&m_workerThread);
    connect(&m_workerThread, &QThread::started, this, &VideoReceiver::process);
}

VideoReceiver::~VideoReceiver() {
    stopStream();
}

void VideoReceiver::startStream(const QString &sourceUrl) {
    m_sourceUrl = sourceUrl;
    m_running = true;
    m_workerThread.start();
}

void VideoReceiver::stopStream() {
    m_running = false;
    m_workerThread.quit();
    m_workerThread.wait();
}

void VideoReceiver::process() {
    emit statusChanged("Łączenie ze źródłem wideo...");

    cv::VideoCapture cap;

    // Sprawdzenie: jeśli podano cyfrę "0", otwórz kamerkę laptopa, jeśli URL - otwórz strumień HTTP
    bool isNumeric;
    int camIndex = m_sourceUrl.toInt(&isNumeric);
    if (isNumeric) {
        cap.open(camIndex);
    } else {
        cap.open(m_sourceUrl.toStdString());
    }

    if (!cap.isOpened()) {
        emit statusChanged("BŁĄD: Nie można otworzyć strumienia: " + m_sourceUrl);
        return;
    }

    emit statusChanged("Połączono. Pobieranie obrazu...");

    cv::Mat frame;
    while (m_running) {
        if (!cap.read(frame) || frame.empty()) {
            QThread::msleep(10);
            continue;
        }

        // Konwersja kolorów OpenCV (BGR) -> Qt (RGB)
        cv::Mat rgbFrame;
        cv::cvtColor(frame, rgbFrame, cv::COLOR_BGR2RGB);

        // Zamiana cv::Mat na QImage
        QImage qimg(rgbFrame.data,
                    rgbFrame.cols,
                    rgbFrame.rows,
                    static_cast<int>(rgbFrame.step),
                    QImage::Format_RGB888);

        // Wysyłamy głęboką kopię do wątku GUI
        emit frameReady(qimg.copy());
    }

    cap.release();
    emit statusChanged("Rozłączono.");
}