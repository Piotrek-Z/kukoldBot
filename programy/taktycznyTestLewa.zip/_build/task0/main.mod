MODULE MOD_MAIN
GLOBAL PROC main()
	While(1)
MoveAbsJ(j1,v1000,z50,tool0,wobj0);
wait(8);
MoveAbsJ(j2,v1000,z50,tool0,wobj0);
wait(2);
MoveAbsJ(j3,v1000,z50,tool0,wobj0);
wait(5);
MoveAbsJ(j2,v1000,z50,tool0,wobj0);
wait(2);
MoveAbsJ(j1,v1000,z50,tool0,wobj0);


endwhile
ENDPROC

ENDMODULE