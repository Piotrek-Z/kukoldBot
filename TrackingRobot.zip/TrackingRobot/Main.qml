import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import TrackingRobot

Window {
    id: rootWindow
    width: 1200
    height: 720
    visible: true
    title: "Rokae Helios"
    color: "#f0f0f0"
    RowLayout {
        anchors.fill: parent
        anchors.margins: 15
        spacing: 15

        // Obszar Podglądu Wideo
        Rectangle {
            id: videoArea
            Layout.fillWidth: true
            Layout.fillHeight: true
            color: "#0f0f12"
            radius: 8
            border.color: "#33333f"
            border.width: 1
            clip: true // Zapobiega wychodzeniu obrazu poza zaokrąglone rogi

            // NASZA KONTROLKA WIDEO:
            VideoItem {
                id: liveDisplay
                objectName: "cameraDisplay" // Ta nazwa pozwala znaleźć kontrolkę w C++
                anchors.fill: parent
            }

            // Nakładka statusu w rogu wideo
            Rectangle {
                anchors.top: parent.top
                anchors.left: parent.left
                anchors.margins: 10
                width: 160
                height: 30
                color: "#80000000"
                radius: 4

                Text {
                    anchors.centerIn: parent
                    text: "ROBOT STREAM: LIVE"
                    color: "#00ff88"
                    font.pixelSize: 12
                    font.bold: true
                }
            }
        }

        Rectangle {
            id: sidePanel
            Layout.preferredWidth: 320
            Layout.fillHeight: true
            color: "#e4e4e4"
            radius: 8
            border.color: "#3b3b4a"
            border.width: 1

            ColumnLayout {
                anchors.fill: parent
                anchors.margins: 15
                spacing: 12

                Text {
                    text: "Sterowanie Robotem"
                    color: "#ffffff"
                    font.pixelSize: 20
                    font.bold: true
                }

                Rectangle {
                    Layout.fillWidth: true
                    height: 1
                    color: "#3b3b4a"
                }

                RowLayout {
                    Layout.fillWidth: true
                    Text { text: "Status Robota:"; color: "#aaaaaa"; font.pixelSize: 14 }
                    Item { Layout.fillWidth: true }
                    Text { text: "POŁĄCZONY"; color: "#00ff88"; font.bold: true; font.pixelSize: 14 }
                }

                GroupBox {
                    title: "Kąty Stawów Człowieka"
                    Layout.fillWidth: true

                    ColumnLayout {
                        anchors.fill: parent
                        spacing: 8

                        RowLayout {
                            Layout.fillWidth: true
                            Text { text: "Zgięcie łokcia:"; color: "#cccccc" }
                            Item { Layout.fillWidth: true }
                            Text { text: "65.4°"; color: "#00ccff"; font.bold: true }
                        }

                        RowLayout {
                            Layout.fillWidth: true
                            Text { text: "Uniesienie barku:"; color: "#cccccc" }
                            Item { Layout.fillWidth: true }
                            Text { text: "32.1°"; color: "#00ccff"; font.bold: true }
                        }
                    }
                }

                Item {
                    Layout.fillHeight: true
                }

                Button {
                    id: btnTracking
                    Layout.fillWidth: true
                    height: 45
                    text: "WŁĄCZ ŚLEDZENIE"
                    highlighted: true
                    onClicked: {
                        console.log("Kliknięto przełącznik śledzenia!")
                    }
                }

                Button {
                    id: btnEstop
                    Layout.fillWidth: true
                    height: 50
                    text: "STOP AWARYJNY (E-STOP)"
                    palette.button: "#cc2222"
                    palette.buttonText: "#ffffff"
                    font.bold: true
                    onClicked: {
                        console.log("WCIŚNIĘTO E-STOP!")
                    }
                }
            }
        }
    }
}