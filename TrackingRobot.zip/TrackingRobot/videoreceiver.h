#pragma once

#include <QObject>
#include <QImage>
#include <QThread>
#include <atomic>
#include <opencv2/opencv.hpp>

class VideoReceiver : public QObject {
    Q_OBJECT
public:
    explicit VideoReceiver(QObject *parent = nullptr);
    ~VideoReceiver();

    // Możesz podać adres URL robota lub "0" dla lokalnej kamerki
    void startStream(const QString &sourceUrl);
    void stopStream();

signals:
    // Sygnał wysyłający nową klatkę do interfejsu
    void frameReady(const QImage &image);
    void statusChanged(const QString &status);

public slots:
    void process();

private:
    std::atomic<bool> m_running{false};
    QString m_sourceUrl;
    QThread m_workerThread;
};