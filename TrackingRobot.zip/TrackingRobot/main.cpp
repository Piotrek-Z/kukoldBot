#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include "videoreceiver.h"
#include "videoitem.h"

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;

    // Tworzymy odbiornik wideo
    VideoReceiver videoReceiver;

    // Rejestrujemy odbiornik w kontekście QML, by móc czytać np. status
    engine.rootContext()->setContextProperty("videoReceiver", &videoReceiver);

    // Rejestracja typu VideoItem dla QML
    qmlRegisterType<VideoItem>("TrackingRobot", 1, 0, "VideoItem");

    QObject::connect(
        &engine,
        &QQmlApplicationEngine::objectCreationFailed,
        &app,
        []() { QCoreApplication::exit(-1); },
        Qt::QueuedConnection);

    engine.loadFromModule("TrackingRobot", "Main");

    // Po załadowaniu QML szukamy naszego VideoItem i łączymy sygnał
    QObject *rootObject = engine.rootObjects().first();
    VideoItem *videoItem = rootObject->findChild<VideoItem*>("cameraDisplay");

    if (videoItem) {
        QObject::connect(&videoReceiver, &VideoReceiver::frameReady,
                         videoItem, &VideoItem::onNewFrame);
    }

    // ========================================================
    // START STRUMIENIA:
    // Użyj adresu URL robota:
    videoReceiver.startStream("http://10.111.169.242:8080/stream?topic=/camera/color/image_raw");

    // LUB jeśli testujesz na laptopie bez robota, zamień na:
    // videoReceiver.startStream("0");
    // ========================================================

    return app.exec();
}